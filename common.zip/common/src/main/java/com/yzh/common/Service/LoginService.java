package com.yzh.common.Service;

public interface LoginService {
    Object login(String username ,String password);
}
