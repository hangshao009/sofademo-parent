package com.yzh.common.Service;

import com.yzh.common.entity.User;

public interface TestService {
    void UpdateUserInfo(User user);
}
