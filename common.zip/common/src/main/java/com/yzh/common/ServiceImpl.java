package com.yzh.common;

import com.alipay.sofa.runtime.api.annotation.SofaService;
import com.alipay.sofa.runtime.api.annotation.SofaServiceBinding;
import com.yzh.common.Service.LoginService;
import com.yzh.common.Service.TestService;
import com.yzh.common.Service.UserService;
import com.yzh.common.entity.User;
import org.springframework.stereotype.Component;

@SofaService(interfaceType = TestService.class,uniqueId = "Test",
        bindings = { @SofaServiceBinding(bindingType = "bolt") })
@Component
public class ServiceImpl implements TestService {

    @Override
    public void UpdateUserInfo(User user) {

    }
}
